define([
  './fixes/img.lazyload'
], function() {});
